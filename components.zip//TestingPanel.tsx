import { useState, useEffect } from "react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Input } from "./ui/input";
import { Play, Trophy, CheckCircle2, XCircle, ArrowRight } from "lucide-react";
import { TestQuestion, UnitType } from "./VirtualCaliper";

interface TestingPanelProps {
  question: TestQuestion | null;
  score: { correct: number; total: number };
  unit: UnitType;
  onStartNewQuestion: () => void;
  onAnswer: (userAnswer: number, isCorrect: boolean) => void;
  showAnswer: boolean;
}

export function TestingPanel({
  question,
  score,
  unit,
  onStartNewQuestion,
  onAnswer,
  showAnswer
}: TestingPanelProps) {
  const [userInput, setUserInput] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "incorrect" | null>(null);

  useEffect(() => {
    setUserInput("");
    setFeedback(null);
  }, [question]);

  const mmToInches = (mm: number) => mm / 25.4;

  const handleSubmit = () => {
    if (!question || !userInput) return;

    const userAnswer = parseFloat(userInput);
    if (isNaN(userAnswer)) return;

    const correctValue = unit === "metric" 
      ? question.targetValue 
      : mmToInches(question.targetValue);

    // Allow for small tolerance in answer
    const tolerance = unit === "metric" ? 0.2 : 0.008;
    const isCorrect = Math.abs(userAnswer - correctValue) <= tolerance;

    setFeedback(isCorrect ? "correct" : "incorrect");
    onAnswer(userAnswer, isCorrect);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !showAnswer) {
      handleSubmit();
    }
  };

  if (!question) {
    return (
      <Card className="p-8 bg-gradient-to-br from-blue-50 to-indigo-50 shadow-lg border-2 border-blue-200">
        <div className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="rounded-full bg-blue-100 p-4">
              <Trophy className="h-12 w-12 text-blue-600" />
            </div>
          </div>
          <h3 className="text-slate-800">Test Your Skills</h3>
          <p className="text-slate-600 max-w-md mx-auto">
            In self-test mode, measurements are hidden. Read the caliper and enter your answer to reveal the correct measurement!
          </p>
          <Button onClick={onStartNewQuestion} size="lg" className="gap-2">
            <Play className="h-5 w-5" />
            Start Self-Test
          </Button>
        </div>
      </Card>
    );
  }

  const accuracy = score.total > 0 ? Math.round((score.correct / score.total) * 100) : 0;

  return (
    <Card className="p-6 bg-white shadow-lg space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="text-sm text-slate-600 mb-1">Your Score</div>
          <div className="flex items-center gap-3">
            <span className="text-3xl text-slate-800">
              {score.correct}/{score.total}
            </span>
            {score.total > 0 && (
              <Badge 
                variant={accuracy >= 80 ? "default" : accuracy >= 60 ? "secondary" : "outline"}
                className="text-base px-3 py-1"
              >
                {accuracy}%
              </Badge>
            )}
          </div>
        </div>
        <div className="text-right">
          <div className="text-sm text-slate-600 mb-1">Question</div>
          <div className="text-2xl text-slate-800">
            #{score.total + 1}
          </div>
        </div>
      </div>

      <div className="border-t pt-6 space-y-4">
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-sm">
            Read the caliper
          </Badge>
          <span className="text-slate-600 text-sm">
            Enter measurement in {unit === "metric" ? "millimeters" : "inches"}
          </span>
        </div>

        {!showAnswer ? (
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                type="number"
                step={unit === "metric" ? "0.01" : "0.0001"}
                placeholder={unit === "metric" ? "e.g., 25.40" : "e.g., 1.0000"}
                value={userInput}
                onChange={(e) => setUserInput(e.target.value)}
                onKeyPress={handleKeyPress}
                className="text-lg"
                autoFocus
              />
              <span className="flex items-center text-slate-600 min-w-[40px]">
                {unit === "metric" ? "mm" : "in"}
              </span>
            </div>
            <Button 
              onClick={handleSubmit} 
              disabled={!userInput}
              className="w-full"
              size="lg"
            >
              Submit Answer
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className={`p-4 rounded-lg border-2 ${
              feedback === "correct" 
                ? "bg-green-50 border-green-300" 
                : "bg-red-50 border-red-300"
            }`}>
              <div className="flex items-center gap-2 mb-2">
                {feedback === "correct" ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    <span className="text-green-800">Correct!</span>
                  </>
                ) : (
                  <>
                    <XCircle className="h-5 w-5 text-red-600" />
                    <span className="text-red-800">Incorrect</span>
                  </>
                )}
              </div>
              <div className="text-sm text-slate-700">
                <div>Your answer: <strong>{userInput} {unit === "metric" ? "mm" : "in"}</strong></div>
                <div>Correct answer: <strong>
                  {unit === "metric" 
                    ? `${question.targetValue.toFixed(2)} mm` 
                    : `${mmToInches(question.targetValue).toFixed(4)} in`}
                </strong></div>
              </div>
            </div>
            
            <Button 
              onClick={onStartNewQuestion}
              className="w-full gap-2"
              size="lg"
            >
              Next Question
              <ArrowRight className="h-5 w-5" />
            </Button>
          </div>
        )}
      </div>
    </Card>
  );
}
