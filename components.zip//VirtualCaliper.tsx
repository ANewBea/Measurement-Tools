import { useState } from "react";
import { CaliperDisplay } from "./CaliperDisplay";
import { TestingPanel } from "./TestingPanel";
import { Card } from "./ui/card";
import { ToggleGroup, ToggleGroupItem } from "./ui/toggle-group";
import { Button } from "./ui/button";
import { RotateCcw } from "lucide-react";

export type UnitType = "metric" | "imperial";

export interface TestQuestion {
  targetValue: number;
  unit: UnitType;
}

export function VirtualCaliper() {
  const [practiceOpening, setPracticeOpening] = useState(25.4); // in mm
  const [practiceUnit, setPracticeUnit] = useState<UnitType>("metric");
  
  const [testOpening, setTestOpening] = useState(0); // in mm
  const [testUnit, setTestUnit] = useState<UnitType>("metric");
  const [currentQuestion, setCurrentQuestion] = useState<TestQuestion | null>(null);
  const [score, setScore] = useState({ correct: 0, total: 0 });
  const [showAnswer, setShowAnswer] = useState(false);

  const maxOpening = 150; // 150mm max

  const generateQuestion = (): TestQuestion => {
    const targetValue = Math.round(Math.random() * 1480 + 10) / 10; // 1.0mm to 149.0mm in 0.1mm increments
    const questionUnit: UnitType = Math.random() > 0.5 ? "metric" : "imperial";
    
    return {
      targetValue,
      unit: questionUnit
    };
  };

  const startNewQuestion = () => {
    const question = generateQuestion();
    setCurrentQuestion(question);
    setTestUnit(question.unit);
    setTestOpening(question.targetValue);
    setShowAnswer(false);
  };

  const handleAnswer = (userAnswer: number, isCorrect: boolean) => {
    setScore(prev => ({
      correct: prev.correct + (isCorrect ? 1 : 0),
      total: prev.total + 1
    }));
    setShowAnswer(true);
  };

  const resetPracticeCaliper = () => {
    setPracticeOpening(0);
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-slate-800 mb-2">Virtual Caliper Trainer</h1>
        <p className="text-slate-600">Practice measuring and test your caliper reading skills</p>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Practice Section */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-slate-800">Practice Mode</h2>
            <Button
              variant="outline"
              size="sm"
              onClick={resetPracticeCaliper}
              className="gap-2"
            >
              <RotateCcw className="h-4 w-4" />
              Reset
            </Button>
          </div>
          
          <Card className="p-6 bg-white shadow-lg">
            <div className="mb-4">
              <label className="text-sm text-slate-600 mb-2 block">
                Measurement Unit
              </label>
              <ToggleGroup 
                type="single" 
                value={practiceUnit} 
                onValueChange={(value) => value && setPracticeUnit(value as UnitType)}
                className="justify-start"
              >
                <ToggleGroupItem value="metric" className="px-6">
                  Metric (mm)
                </ToggleGroupItem>
                <ToggleGroupItem value="imperial" className="px-6">
                  Imperial (in)
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
            
            <CaliperDisplay 
              opening={practiceOpening}
              unit={practiceUnit}
              maxOpening={maxOpening}
              onOpeningChange={setPracticeOpening}
              interactive={true}
              showMeasurement={true}
            />
          </Card>
          
          <Card className="p-4 bg-slate-50">
            <p className="text-sm text-slate-600">
              <strong>How to use:</strong> Drag the moving jaw (right side) left or right to adjust the caliper opening. 
              The digital display shows the current measurement in both metric and imperial units.
            </p>
          </Card>
        </div>

        {/* Test Section */}
        <div className="space-y-4">
          <h2 className="text-slate-800">Self-Test Mode</h2>
          
          <Card className="p-6 bg-white shadow-lg">
            <CaliperDisplay 
              opening={testOpening}
              unit={testUnit}
              maxOpening={maxOpening}
              onOpeningChange={setTestOpening}
              interactive={false}
              showMeasurement={showAnswer}
            />
          </Card>

          <TestingPanel
            question={currentQuestion}
            score={score}
            unit={testUnit}
            onStartNewQuestion={startNewQuestion}
            onAnswer={handleAnswer}
            showAnswer={showAnswer}
          />
        </div>
      </div>
    </div>
  );
}
