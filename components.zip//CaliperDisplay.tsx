import { useRef, useEffect, useState } from "react";
import { UnitType } from "./VirtualCaliper";

interface CaliperDisplayProps {
  opening: number; // in mm
  unit: UnitType;
  maxOpening: number;
  onOpeningChange: (value: number) => void;
  interactive: boolean;
  showMeasurement: boolean;
}

export function CaliperDisplay({ 
  opening, 
  unit, 
  maxOpening, 
  onOpeningChange,
  interactive,
  showMeasurement
}: CaliperDisplayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, opening: 0 });

  const mmToInches = (mm: number) => mm / 25.4;
  const displayValue = unit === "metric" ? opening : mmToInches(opening);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    
    ctx.scale(dpr, dpr);

    const width = rect.width;
    const height = rect.height;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // Zoomed view parameters - show a window of about 40mm centered on the opening
    const viewWindowMm = 40; // How many mm to show in the window
    const viewCenter = Math.max(viewWindowMm/2, Math.min(maxOpening - viewWindowMm/2, opening));
    const viewStart = viewCenter - viewWindowMm/2;
    const viewEnd = viewCenter + viewWindowMm/2;
    
    // Much higher zoom - pixels per mm for zoomed view
    const pixelsPerMm = (width * 0.85) / viewWindowMm;
    
    // Calculate screen positions
    const toScreenX = (mmPos: number) => {
      return (mmPos - viewStart) * pixelsPerMm + width * 0.075;
    };
    
    const fixedJawScreenX = toScreenX(0);
    const movingJawScreenX = toScreenX(opening);

    // Helper function for gradients
    const createMetalGradient = (x: number, y: number, w: number, h: number) => {
      const gradient = ctx.createLinearGradient(x, y, x, y + h);
      gradient.addColorStop(0, "#b0b8c0");
      gradient.addColorStop(0.3, "#e8eef2");
      gradient.addColorStop(0.5, "#c8d0d8");
      gradient.addColorStop(0.7, "#e8eef2");
      gradient.addColorStop(1, "#98a0a8");
      return gradient;
    };

    // Draw main beam
    const beamY = 140;
    const beamHeight = 60;
    const beamScreenStart = toScreenX(Math.max(0, viewStart));
    const beamScreenEnd = toScreenX(Math.min(maxOpening, viewEnd));
    const beamWidth = beamScreenEnd - beamScreenStart;
    
    ctx.fillStyle = createMetalGradient(beamScreenStart, beamY, beamWidth, beamHeight);
    ctx.fillRect(beamScreenStart, beamY, beamWidth, beamHeight);
    
    // Beam edges
    ctx.strokeStyle = "#5a6268";
    ctx.lineWidth = 3;
    ctx.strokeRect(beamScreenStart, beamY, beamWidth, beamHeight);
    
    // Top edge highlight
    ctx.strokeStyle = "#ffffff";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(beamScreenStart + 3, beamY + 3);
    ctx.lineTo(beamScreenStart + beamWidth - 3, beamY + 3);
    ctx.stroke();

    // Draw scale markings on main beam
    ctx.save();
    ctx.fillStyle = "#000000";
    ctx.strokeStyle = "#000000";
    ctx.font = "16px Arial"; // 12pt = 16px
    
    if (unit === "metric") {
      // Main divisions every 10mm
      ctx.lineWidth = 2.5;
      const startMm = Math.floor(viewStart / 10) * 10;
      const endMm = Math.ceil(viewEnd / 10) * 10;
      
      for (let i = startMm; i <= endMm; i += 10) {
        const x = toScreenX(i);
        if (x >= beamScreenStart && x <= beamScreenEnd) {
          ctx.beginPath();
          ctx.moveTo(x, beamY + 8);
          ctx.lineTo(x, beamY + 30);
          ctx.stroke();
          
          ctx.fillText(i.toString(), x - (i >= 100 ? 15 : i >= 10 ? 10 : 5), beamY + 50);
        }
      }

      // Minor divisions every 1mm
      ctx.lineWidth = 1.5;
      for (let i = Math.floor(viewStart); i <= Math.ceil(viewEnd); i += 1) {
        if (i % 10 !== 0) {
          const x = toScreenX(i);
          if (x >= beamScreenStart && x <= beamScreenEnd) {
            ctx.beginPath();
            ctx.moveTo(x, beamY + 8);
            ctx.lineTo(x, i % 5 === 0 ? beamY + 25 : beamY + 20);
            ctx.stroke();
          }
        }
      }
    } else {
      // Imperial scale
      const startInches = Math.floor(mmToInches(viewStart));
      const endInches = Math.ceil(mmToInches(viewEnd));
      
      ctx.lineWidth = 2.5;
      for (let i = startInches; i <= endInches; i++) {
        const mmPos = i * 25.4;
        const x = toScreenX(mmPos);
        if (x >= beamScreenStart && x <= beamScreenEnd) {
          ctx.beginPath();
          ctx.moveTo(x, beamY + 8);
          ctx.lineTo(x, beamY + 30);
          ctx.stroke();
          ctx.fillText(i.toString(), x - 8, beamY + 50);
        }
      }

      // 1/16 inch divisions
      ctx.lineWidth = 1.5;
      const start16ths = Math.floor(mmToInches(viewStart) * 16);
      const end16ths = Math.ceil(mmToInches(viewEnd) * 16);
      
      for (let i = start16ths; i <= end16ths; i++) {
        if (i % 16 !== 0) {
          const mmPos = (i / 16) * 25.4;
          const x = toScreenX(mmPos);
          if (x >= beamScreenStart && x <= beamScreenEnd) {
            ctx.beginPath();
            ctx.moveTo(x, beamY + 8);
            const tickHeight = i % 8 === 0 ? 25 : i % 4 === 0 ? 22 : i % 2 === 0 ? 18 : 15;
            ctx.lineTo(x, beamY + tickHeight);
            ctx.stroke();
          }
        }
      }
    }
    ctx.restore();

    // Draw fixed jaw (left side) - only if visible
    if (fixedJawScreenX >= -50 && fixedJawScreenX <= width) {
      const jawWidth = 30;
      
      // Fixed jaw upper arm
      ctx.fillStyle = createMetalGradient(fixedJawScreenX - jawWidth/2, 20, jawWidth, 120);
      ctx.fillRect(fixedJawScreenX - jawWidth/2, 20, jawWidth, 120);
      ctx.strokeStyle = "#5a6268";
      ctx.lineWidth = 2.5;
      ctx.strokeRect(fixedJawScreenX - jawWidth/2, 20, jawWidth, 120);
      
      // Fixed jaw lower arm
      ctx.fillStyle = createMetalGradient(fixedJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
      ctx.fillRect(fixedJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
      ctx.strokeRect(fixedJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
      
      // Fixed jaw measuring surfaces
      ctx.fillStyle = createMetalGradient(fixedJawScreenX - jawWidth/2, 0, jawWidth, 20);
      ctx.fillRect(fixedJawScreenX - jawWidth/2, 0, jawWidth, 20);
      ctx.strokeRect(fixedJawScreenX - jawWidth/2, 0, jawWidth, 20);
      
      ctx.fillStyle = createMetalGradient(fixedJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);
      ctx.fillRect(fixedJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);
      ctx.strokeRect(fixedJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);
    }

    // Draw moving jaw (always visible since it's what we're measuring)
    const jawWidth = 30;
    const sliderWidth = 70;
    
    // Moving jaw slider body
    ctx.fillStyle = createMetalGradient(movingJawScreenX - 20, beamY - 5, sliderWidth, beamHeight + 10);
    ctx.fillRect(movingJawScreenX - 20, beamY - 5, sliderWidth, beamHeight + 10);
    ctx.strokeStyle = "#5a6268";
    ctx.lineWidth = 3;
    ctx.strokeRect(movingJawScreenX - 20, beamY - 5, sliderWidth, beamHeight + 10);
    
    // Thumb wheel for dragging
    const thumbX = movingJawScreenX + 35;
    const thumbY = beamY + beamHeight / 2;
    const thumbRadius = 30;
    
    const thumbGradient = ctx.createRadialGradient(thumbX, thumbY, 0, thumbX, thumbY, thumbRadius);
    thumbGradient.addColorStop(0, "#d0d8e0");
    thumbGradient.addColorStop(0.7, "#98a0a8");
    thumbGradient.addColorStop(1, "#6a7278");
    
    ctx.fillStyle = thumbGradient;
    ctx.beginPath();
    ctx.arc(thumbX, thumbY, thumbRadius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#5a6268";
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Knurling pattern on thumb wheel
    ctx.strokeStyle = "#4a5258";
    ctx.lineWidth = 2;
    for (let i = 0; i < 24; i++) {
      const angle = (i * Math.PI * 2) / 24;
      const x1 = thumbX + Math.cos(angle) * (thumbRadius - 8);
      const y1 = thumbY + Math.sin(angle) * (thumbRadius - 8);
      const x2 = thumbX + Math.cos(angle) * thumbRadius;
      const y2 = thumbY + Math.sin(angle) * thumbRadius;
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    }
    
    // Moving jaw upper arm
    ctx.fillStyle = createMetalGradient(movingJawScreenX - jawWidth/2, 20, jawWidth, 120);
    ctx.fillRect(movingJawScreenX - jawWidth/2, 20, jawWidth, 120);
    ctx.strokeStyle = "#5a6268";
    ctx.lineWidth = 2.5;
    ctx.strokeRect(movingJawScreenX - jawWidth/2, 20, jawWidth, 120);
    
    // Moving jaw lower arm
    ctx.fillStyle = createMetalGradient(movingJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
    ctx.fillRect(movingJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
    ctx.strokeRect(movingJawScreenX - jawWidth/2, beamY + beamHeight, jawWidth, 140);
    
    // Moving jaw measuring surfaces
    ctx.fillStyle = createMetalGradient(movingJawScreenX - jawWidth/2, 0, jawWidth, 20);
    ctx.fillRect(movingJawScreenX - jawWidth/2, 0, jawWidth, 20);
    ctx.strokeRect(movingJawScreenX - jawWidth/2, 0, jawWidth, 20);
    
    ctx.fillStyle = createMetalGradient(movingJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);
    ctx.fillRect(movingJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);
    ctx.strokeRect(movingJawScreenX - jawWidth/2, beamY + beamHeight + 140, jawWidth, 40);

    // Draw vernier scale on moving jaw slider
    const vernierWidth = 60;
    ctx.fillStyle = "#f8f9fa";
    ctx.fillRect(movingJawScreenX - 15, beamY + 2, vernierWidth, 22);
    ctx.strokeStyle = "#5a6268";
    ctx.lineWidth = 2;
    ctx.strokeRect(movingJawScreenX - 15, beamY + 2, vernierWidth, 22);
    
    // Vernier markings
    ctx.strokeStyle = "#000000";
    ctx.fillStyle = "#000000";
    ctx.font = "12px Arial";
    ctx.lineWidth = 1.5;
    
    const vernierDivisions = unit === "metric" ? 10 : 8;
    for (let i = 0; i <= vernierDivisions; i++) {
      const x = movingJawScreenX - 15 + (i * vernierWidth / vernierDivisions);
      ctx.beginPath();
      ctx.moveTo(x, beamY + 2);
      ctx.lineTo(x, beamY + (i % 5 === 0 ? 15 : 12));
      ctx.stroke();
      
      if (i % 5 === 0) {
        ctx.fillText(i.toString(), x - 4, beamY + 22);
      }
    }

    // Measurement gap indicator
    if (opening > 0.5 && fixedJawScreenX >= -50) {
      ctx.strokeStyle = "#ef4444";
      ctx.lineWidth = 3;
      ctx.setLineDash([6, 6]);
      ctx.beginPath();
      ctx.moveTo(fixedJawScreenX + jawWidth/2, 60);
      ctx.lineTo(movingJawScreenX - jawWidth/2, 60);
      ctx.stroke();
      ctx.setLineDash([]);
      
      // Arrows
      ctx.fillStyle = "#ef4444";
      ctx.beginPath();
      ctx.moveTo(fixedJawScreenX + jawWidth/2 + 5, 60);
      ctx.lineTo(fixedJawScreenX + jawWidth/2 + 12, 56);
      ctx.lineTo(fixedJawScreenX + jawWidth/2 + 12, 64);
      ctx.fill();
      
      ctx.beginPath();
      ctx.moveTo(movingJawScreenX - jawWidth/2 - 5, 60);
      ctx.lineTo(movingJawScreenX - jawWidth/2 - 12, 56);
      ctx.lineTo(movingJawScreenX - jawWidth/2 - 12, 64);
      ctx.fill();
    }

  }, [opening, unit, maxOpening]);

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!interactive) return;
    setIsDragging(true);
    setDragStart({ x: e.clientX, opening });
  };

  const handleTouchStart = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (!interactive) return;
    const touch = e.touches[0];
    setIsDragging(true);
    setDragStart({ x: touch.clientX, opening });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  useEffect(() => {
    if (isDragging) {
      const handleGlobalMouseMove = (e: MouseEvent) => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        
        const rect = canvas.getBoundingClientRect();
        const viewWindowMm = 40;
        const pixelsPerMm = (rect.width * 0.85) / viewWindowMm;
        
        const deltaX = e.clientX - dragStart.x;
        const deltaMm = deltaX / pixelsPerMm;
        const newOpening = Math.max(0, Math.min(maxOpening, dragStart.opening + deltaMm));
        
        onOpeningChange(parseFloat(newOpening.toFixed(1)));
      };

      const handleGlobalTouchMove = (e: TouchEvent) => {
        const canvas = canvasRef.current;
        if (!canvas) return;
        
        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        const viewWindowMm = 40;
        const pixelsPerMm = (rect.width * 0.85) / viewWindowMm;
        
        const deltaX = touch.clientX - dragStart.x;
        const deltaMm = deltaX / pixelsPerMm;
        const newOpening = Math.max(0, Math.min(maxOpening, dragStart.opening + deltaMm));
        
        onOpeningChange(parseFloat(newOpening.toFixed(1)));
      };

      const handleGlobalMouseUp = () => {
        setIsDragging(false);
      };

      window.addEventListener("mousemove", handleGlobalMouseMove);
      window.addEventListener("mouseup", handleGlobalMouseUp);
      window.addEventListener("touchmove", handleGlobalTouchMove);
      window.addEventListener("touchend", handleGlobalMouseUp);

      return () => {
        window.removeEventListener("mousemove", handleGlobalMouseMove);
        window.removeEventListener("mouseup", handleGlobalMouseUp);
        window.removeEventListener("touchmove", handleGlobalTouchMove);
        window.removeEventListener("touchend", handleGlobalMouseUp);
      };
    }
  }, [isDragging, dragStart, maxOpening, onOpeningChange]);

  return (
    <div className="space-y-4">
      <canvas
        ref={canvasRef}
        className={`w-full ${interactive ? 'cursor-grab active:cursor-grabbing' : 'cursor-default'}`}
        style={{ width: "100%", height: "400px" }}
        onMouseDown={handleMouseDown}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      />
      
      <div className={`bg-slate-900 text-green-400 p-4 rounded-lg font-mono text-center transition-all duration-300 ${!showMeasurement ? 'opacity-50 blur-sm select-none' : ''}`}>
        <div className="text-xs text-slate-500 mb-1">
          {showMeasurement ? "MEASUREMENT" : "HIDDEN - ANSWER TO REVEAL"}
        </div>
        <div className="text-2xl">
          {showMeasurement ? (
            <>
              {unit === "metric" 
                ? `${displayValue.toFixed(2)} mm` 
                : `${displayValue.toFixed(4)} in`}
            </>
          ) : (
            "•••••"
          )}
        </div>
        {showMeasurement && (
          <div className="text-xs text-slate-500 mt-2">
            {unit === "metric" 
              ? `≈ ${mmToInches(opening).toFixed(4)} in` 
              : `≈ ${opening.toFixed(2)} mm`}
          </div>
        )}
      </div>
    </div>
  );
}
